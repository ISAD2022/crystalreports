using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class ZoneWiseOldParasPerformanceModel
    {        
        public string ZONEID { get; set; }
        public string ZONENAME { get; set; }
        public string PARA_ENTERED { get; set; }
        public string PARA_PENDING { get; set; }
        public string PARA_TOTAL { get; set; }
    }
}
