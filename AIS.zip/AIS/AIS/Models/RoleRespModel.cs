using System;

namespace AIS.Models
{
    public class RoleRespModel
    {
        
        public int DESIGNATIONCODE { get; set; }
        public string DESCRIPTION { get; set; }
        public string STATUS { get; set; }

    }
}
