using System;

namespace AIS.Models
{
    public class MenuModel
    {        
        public int Menu_Id { get; set; }
        public string Menu_Name { get; set; }
        public string Menu_Order { get; set; }
        public string Menu_Description { get; set; }
    }
}
