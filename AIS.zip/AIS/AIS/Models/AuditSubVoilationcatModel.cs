using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class AuditSubVoilationcatModel
    {
        public int ID { get; set; }
        public int V_ID { get; set; }
        public string SUB_V_NAME { get; set; }

        public string RISK_ID { get; set; }

        public string STATUS { get; set; }

    }
}
