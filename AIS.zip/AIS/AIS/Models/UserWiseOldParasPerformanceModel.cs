using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class UserWiseOldParasPerformanceModel
    {        
        public string AUDIT_ZONEID { get; set; }
        public string ZONENAME { get; set; }
        public string PPNO { get; set; }
        public string PARA_ENTERED { get; set; }
    }
}
