using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class RiskModel
    {
        public int R_ID { get; set; }
        public string DESCRIPTION { get; set; }
        public string RATING { get; set; }

    }
}
