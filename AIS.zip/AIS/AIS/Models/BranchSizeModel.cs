using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace AIS.Models
{
    public class BranchSizeModel
    {        
        public int BR_SIZE_ID { get; set; }
        public string DESCRIPTION { get; set; }
    }
}
