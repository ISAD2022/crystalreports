﻿namespace AIS.Models
{
    public class ObservationModelBase
    {
        public string TEXT { get; set; }
    }
}