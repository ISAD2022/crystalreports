using System;

namespace AIS.Models
{
    public class AuditSubEntitiesModel
    {
        public int E_ID { get; set; }
        public int ID { get; set; }
        public string NAME { get; set; }
        public int DIV_ID { get; set; }
        public int DEP_ID { get; set; }
        public string STATUS { get; set; }

    }
}
