using System;

namespace AIS.Models
{
    public class DivisionModel
    {        
        public int DIVISIONID { get; set; }
        public string NAME { get; set; }
        public string CODE { get; set; }
        public string DESCRIPTION { get; set; }
        public string ISACTIVE { get; set; }
      
    }
}
