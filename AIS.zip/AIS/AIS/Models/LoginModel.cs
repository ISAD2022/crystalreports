using System;

namespace AIS.Models
{
    public class LoginModel
    {
        public string PPNumber { get; set; }
        public string Password { get; set; }
    }
}
